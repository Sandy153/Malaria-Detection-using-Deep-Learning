Malaria Detection using Deep Learning

Project Structure:

1. Create a folder named 'dataset'
2. Inside dataset folder create:
   - Parasitized
   - Uninfected
3. Put respective images inside folders.

Steps to Run:

1. Install requirements:
   pip install -r requirements.txt

2. Train model:
   python train.py

3. Test prediction:
   python predict.py

Dataset Source:
NIH Malaria Cell Images Dataset
