import tensorflow as tf
import numpy as np
import cv2

IMG_SIZE = 64

model = tf.keras.models.load_model("model.h5")

image_path = "test_image.jpg"
img = cv2.imread(image_path)
img = cv2.resize(img, (IMG_SIZE, IMG_SIZE))
img = img / 255.0
img = np.reshape(img, (1, IMG_SIZE, IMG_SIZE, 3))

prediction = model.predict(img)

if prediction[0][0] > 0.5:
    print("Parasitized (Malaria Infected)")
else:
    print("Uninfected (Healthy)")